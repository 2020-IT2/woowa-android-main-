package com.woowahan.woowahanfoods.DataModel;

import java.util.ArrayList;

public class City {
    public String name;
    public City(String cityname){
        this.name = cityname;
    }
    public String getName(){
        return this.name;
    }


}

package com.woowahan.woowahanfoods.DataModel;

public class Hashtag {
    public String hashtag;
    public String sim;
}

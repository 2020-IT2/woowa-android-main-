package com.woowahan.woowahanfoods.DataModel;

public class Juso{
    public String detBdNmList;
    public String engAddr;
    public String rn;
    public String emdNm;
    public String zipNo;
    public String roadAddrPart2;
    public String emdNo;
    public String sggNm;
    public String jibunAddr;
    public String siNm;
    public String roadAddrPart1;
    public String bdNm;
    public String admCd;
    public String udrtYn;
    public String lnbrMnnm;
    public String roadAddr;
    public String lnbrSlno;
    public int buldMnnm;
    public String bdKdcd;
    public String liNm;
    public String rnMgtSn;
    public String mtYn;
    public String bdMgtSn;
    public int buldSlno;
    public String entX;
    public String entY;
}
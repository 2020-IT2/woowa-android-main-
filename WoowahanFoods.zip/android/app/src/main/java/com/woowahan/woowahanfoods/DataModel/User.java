package com.woowahan.woowahanfoods.DataModel;

public class User {
    public int id;

    public User(int id){
        this.id = id;
    }
}

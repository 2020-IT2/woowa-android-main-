package com.woowahan.woowahanfoods.Dataframe;

import java.util.ArrayList;

public class CoordinateFrame{
    public String name;
    public ArrayList<Coordinate> coor;

    public class Coordinate{
        public double x;
        public double y;
    }
}

package com.woowahan.woowahanfoods.Dataframe;

import com.woowahan.woowahanfoods.DataModel.Restaurant;

import java.util.ArrayList;

public class FeedResult {
    public ArrayList<Restaurant> data;
}

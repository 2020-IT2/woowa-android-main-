package com.woowahan.woowahanfoods.Dataframe;

import com.woowahan.woowahanfoods.DataModel.Hashtag;
import com.woowahan.woowahanfoods.httpConnection.BaseResponse;

import java.util.ArrayList;

public class HashtagData extends BaseResponse {
    public ArrayList<Hashtag> body;
}

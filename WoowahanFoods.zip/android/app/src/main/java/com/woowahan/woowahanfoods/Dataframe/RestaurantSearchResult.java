package com.woowahan.woowahanfoods.Dataframe;

import com.woowahan.woowahanfoods.DataModel.Restaurant;
import com.woowahan.woowahanfoods.httpConnection.BaseResponse;

import java.util.ArrayList;

public class RestaurantSearchResult extends BaseResponse {
    public ArrayList<Restaurant> body;
}
